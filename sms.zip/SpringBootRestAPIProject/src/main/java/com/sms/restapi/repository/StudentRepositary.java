package com.sms.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sms.restapi.entity.Student;

public interface StudentRepositary extends JpaRepository<Student, Integer> {

}
